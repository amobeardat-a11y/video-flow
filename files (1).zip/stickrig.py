"""stickrig.py — Rig người que chuẩn (2D, thuần Python, không cần thư viện ngoài).

Quy ước (xem thêm assets/rigs/default.rig.json):
  * Toạ độ màn hình: x sang phải, y xuống dưới. Gốc của nhân vật = hông (pelvis).
  * Góc thế giới: 0° = chỉ xuống, +90° = sang phải, 180° = lên, -90° = sang trái.
  * Góc trong Pose là góc TƯƠNG ĐỐI so với xương cha; pose rỗng = đứng thẳng, tay buông.
  * Dấu (+) = quay về bên phải màn hình (với facing=1 tức là "về phía trước").
  * root = xoay cả người quanh hông; torso = gập thân (chân không bị kéo theo).
  * l_ = bên trái màn hình, r_ = bên phải màn hình.

Dùng nhanh:
    rig = Rig.load("assets/rigs/default.rig.json", variant="kid")
    pose = make_pose("wave_a", x=200, y=0)
    pose = rig.ground(pose, floor_y=300)
    svg = svg_document(figure_svg(rig, pose), 400, 400)
"""
from __future__ import annotations

import json
import math
from dataclasses import dataclass, field
from pathlib import Path

# --------------------------------------------------------------------------
# Hình học cơ bản
# --------------------------------------------------------------------------


def _dir(deg: float) -> tuple[float, float]:
    r = math.radians(deg)
    return math.sin(r), math.cos(r)


def _norm(deg: float) -> float:
    """Chuẩn hoá góc về (-180, 180]."""
    deg = (deg + 180.0) % 360.0 - 180.0
    return 180.0 if deg == -180.0 else deg


def _clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


def two_bone_ik(origin, target, l1, l2, bend=1):
    """IK 2 xương. Trả về (góc thế giới xương 1, góc thế giới xương 2) theo độ.

    bend=+1: khớp giữa (khuỷu/gối) nhô về phía +x; bend=-1: nhô về phía -x.
    Nếu target quá xa/quá gần, kết quả là tư thế gần nhất có thể.
    """
    dx, dy = target[0] - origin[0], target[1] - origin[1]
    d = math.hypot(dx, dy)
    d = _clamp(d, abs(l1 - l2) + 1e-6, l1 + l2 - 1e-6)
    base = math.atan2(dx, dy)
    cos_a = (l1 * l1 + d * d - l2 * l2) / (2 * l1 * d)
    a = math.acos(_clamp(cos_a, -1.0, 1.0))
    th1 = base + bend * a
    mid = (origin[0] + l1 * math.sin(th1), origin[1] + l1 * math.cos(th1))
    th2 = math.atan2(target[0] - mid[0], target[1] - mid[1])
    return math.degrees(th1), math.degrees(th2)


# --------------------------------------------------------------------------
# Pose
# --------------------------------------------------------------------------

JOINTS = [
    "root", "torso", "head",
    "l_arm", "l_forearm", "r_arm", "r_forearm",
    "l_thigh", "l_shin", "l_foot", "r_thigh", "r_shin", "r_foot",
]

EYES = ("dot", "closed", "happy", "wide", "none")
MOUTHS = ("smile", "flat", "open", "sad", "none")


@dataclass
class Pose:
    x: float = 0.0            # vị trí hông (pixel)
    y: float = 0.0
    angles: dict = field(default_factory=dict)   # tên khớp -> độ (thiếu = 0)
    facing: int = 1           # 1 = quay mặt sang phải, -1 = sang trái
    scale: float = 1.0
    eyes: str = "dot"
    mouth: str = "smile"
    view: str = "front"       # "front" (2 mắt) hoặc "side" (1 mắt lệch về phía trước)

    def copy(self) -> "Pose":
        return Pose(self.x, self.y, dict(self.angles), self.facing, self.scale,
                    self.eyes, self.mouth, self.view)

    def get(self, joint: str) -> float:
        return self.angles.get(joint, 0.0)


def lerp_pose(a: Pose, b: Pose, t: float) -> Pose:
    """Nội suy tuyến tính giữa 2 pose (t trong [0,1]). Biểu cảm lấy theo b khi t >= 0.5."""
    out = a.copy()
    out.x = a.x + (b.x - a.x) * t
    out.y = a.y + (b.y - a.y) * t
    out.scale = a.scale + (b.scale - a.scale) * t
    for j in JOINTS:
        va, vb = a.get(j), b.get(j)
        out.angles[j] = va + (vb - va) * t
    if t >= 0.5:
        out.facing, out.eyes, out.mouth, out.view = b.facing, b.eyes, b.mouth, b.view
    return out


def mirror_pose(p: Pose) -> Pose:
    """Lật gương: đổi l_<->r_ và đổi dấu mọi góc (động tác đối xứng trái/phải)."""
    out = p.copy()
    out.angles = {}
    for j in JOINTS:
        if j.startswith("l_"):
            src = "r_" + j[2:]
        elif j.startswith("r_"):
            src = "l_" + j[2:]
        else:
            src = j
        out.angles[j] = -p.get(src)
    return out


EASINGS = {
    "linear": lambda t: t,
    "ease_in": lambda t: t * t,
    "ease_out": lambda t: 1 - (1 - t) ** 2,
    "ease_in_out": lambda t: 3 * t * t - 2 * t ** 3,
}


# --------------------------------------------------------------------------
# Rig
# --------------------------------------------------------------------------


@dataclass
class Bone:
    name: str
    parent: str | None
    length: float
    base: float
    sign: int = 1
    attach: str = "end"
    limits: tuple | None = None


@dataclass
class Seg:
    start: tuple
    end: tuple
    world: float   # góc thế giới (trước khi lật theo facing)


@dataclass
class Solved:
    segs: dict
    anchors: dict


class Rig:
    def __init__(self, spec: dict, variant: str | None = None):
        self.spec = spec
        v = spec.get("variants", {}).get(variant or "default", {})
        k_torso, k_arms = v.get("torso", 1.0), v.get("arms", 1.0)
        k_legs, k_head = v.get("legs", 1.0), v.get("head", 1.0)
        self.line_scale = v.get("line", 1.0)
        self.head_r = spec.get("head_radius", 14) * k_head
        self.variant = variant or "default"

        self.bones: dict[str, Bone] = {}
        for b in spec["bones"]:
            n = b["name"]
            if n == "torso":
                k = k_torso
            elif n.endswith(("arm", "forearm")):
                k = k_arms
            elif n.endswith(("thigh", "shin", "foot")):
                k = k_legs
            else:
                k = 1.0
            parent = b.get("parent")
            if parent is not None and parent not in self.bones:
                raise ValueError(f"Xương '{n}': cha '{parent}' phải khai báo trước.")
            self.bones[n] = Bone(
                n, parent, b["length"] * k, b.get("base", 0.0), b.get("sign", 1),
                b.get("attach", "end"), tuple(b["limits"]) if b.get("limits") else None,
            )

    @classmethod
    def load(cls, path: str | Path, variant: str | None = None) -> "Rig":
        with open(path, encoding="utf-8") as f:
            return cls(json.load(f), variant)

    @property
    def variants(self) -> list[str]:
        return list(self.spec.get("variants", {"default": {}}).keys())

    # ---- Forward kinematics ------------------------------------------------
    def solve(self, pose: Pose, clamp: bool = True) -> Solved:
        local: dict[str, Seg] = {}
        for name, b in self.bones.items():
            ang = pose.get(name)
            if clamp and b.limits:
                ang = _clamp(ang, b.limits[0], b.limits[1])
            if b.parent is None:
                start, pw = (0.0, 0.0), 0.0
            else:
                p = local[b.parent]
                start = p.start if b.attach == "start" else p.end
                pw = p.world
            world = pw + b.base + b.sign * ang
            dx, dy = _dir(world)
            end = (start[0] + b.length * dx, start[1] + b.length * dy)
            local[name] = Seg(start, end, world)

        def to_screen(pt):
            return (pose.x + pose.facing * pose.scale * pt[0],
                    pose.y + pose.scale * pt[1])

        segs = {n: Seg(to_screen(s.start), to_screen(s.end), s.world) for n, s in local.items()}

        hd = local["head"]
        hx, hy = _dir(hd.world)
        head_c = (hd.end[0] + hx * self.head_r, hd.end[1] + hy * self.head_r)
        anchors = {
            "root": to_screen((0.0, 0.0)),
            "neck": segs["torso"].end,
            "head_center": to_screen(head_c),
            "l_hand": segs["l_forearm"].end, "r_hand": segs["r_forearm"].end,
            "l_elbow": segs["l_forearm"].start, "r_elbow": segs["r_forearm"].start,
            "l_knee": segs["l_shin"].start, "r_knee": segs["r_shin"].start,
            "l_ankle": segs["l_shin"].end, "r_ankle": segs["r_shin"].end,
            "l_toe": segs["l_foot"].end, "r_toe": segs["r_foot"].end,
        }
        return Solved(segs, anchors)

    # ---- Tiện ích --------------------------------------------------------------
    def ground(self, pose: Pose, floor_y: float) -> Pose:
        """Dịch pose theo trục y để điểm thấp nhất của chân chạm sàn floor_y."""
        a = self.solve(pose).anchors
        lowest = max(a[k][1] for k in ("l_ankle", "r_ankle", "l_toe", "r_toe"))
        out = pose.copy()
        out.y += floor_y - lowest
        return out

    def ik(self, pose: Pose, limb: str, target: tuple, bend: int | None = None) -> Pose:
        """Đặt tay/chân (limb: l_arm, r_arm, l_leg, r_leg) chạm điểm `target` (toạ độ màn hình)."""
        spec = self.spec["limbs"][limb]
        b1, b2 = (self.bones[n] for n in spec["bones"])
        bend = spec["bend"] if bend is None else bend
        res = self.solve(pose)
        origin_s = res.segs[b1.name].start

        def to_local(pt):
            return (pose.facing * (pt[0] - pose.x) / pose.scale, (pt[1] - pose.y) / pose.scale)

        th1, th2 = two_bone_ik(to_local(origin_s), to_local(target), b1.length, b2.length, bend)
        parent_world = res.segs[b1.parent].world
        out = pose.copy()
        out.angles[b1.name] = _norm((th1 - parent_world - b1.base) / b1.sign)
        out.angles[b2.name] = _norm((th2 - th1 - b2.base) / b2.sign)
        return out

    def height(self) -> float:
        """Chiều cao ước lượng (từ chân đến đỉnh đầu) ở scale=1, pose đứng thẳng."""
        legs = sum(self.bones[n].length for n in ("r_thigh", "r_shin"))
        return legs + self.bones["torso"].length + self.bones["head"].length + 2 * self.head_r


# --------------------------------------------------------------------------
# Thư viện pose mẫu (chỉ là điểm khởi đầu — mở rộng ở assets/motions/)
# --------------------------------------------------------------------------

_SPLAY = {"l_arm": -8, "r_arm": 8, "l_thigh": -5, "r_thigh": 5}

POSES: dict[str, dict] = {
    "neutral": dict(_SPLAY),
    "cheer": {"l_arm": -135, "r_arm": 135, "l_forearm": -25, "r_forearm": 25, "l_thigh": -10, "r_thigh": 10},
    "wave_a": {**_SPLAY, "r_arm": 140, "r_forearm": 35},
    "wave_b": {**_SPLAY, "r_arm": 140, "r_forearm": -15},
    "point_fwd": {**_SPLAY, "r_arm": 90, "r_forearm": 0, "torso": 4},
    "hands_on_hips": {**_SPLAY, "l_arm": -55, "l_forearm": 75, "r_arm": 55, "r_forearm": -75},
    "think": {**_SPLAY, "r_arm": 40, "r_forearm": 140, "head": 8, "torso": 3},
    "shrug": {**_SPLAY, "l_arm": -20, "l_forearm": -100, "r_arm": 20, "r_forearm": 100},
    "lean_forward": {**_SPLAY, "torso": 22, "head": -8, "r_arm": 30, "l_arm": -30},
    "crouch": {"torso": 30, "head": -18, "l_thigh": 80, "r_thigh": 80, "l_shin": -130, "r_shin": -130,
               "l_arm": -20, "r_arm": 20, "l_forearm": 70, "r_forearm": 70},
    "fall_back": {"root": -50, "head": -10, "l_arm": -130, "r_arm": 120, "l_thigh": 20, "r_thigh": 40,
                  "r_shin": -50},
}


def _apply(p: Pose, overrides: dict) -> Pose:
    for k, v in overrides.items():
        if k in JOINTS:
            p.angles[k] = v
        else:
            setattr(p, k, v)
    return p


def make_pose(name: str = "neutral", **overrides) -> Pose:
    """Tạo Pose từ tên pose mẫu. overrides: x, y, facing, scale, eyes, mouth, view hoặc tên khớp."""
    return _apply(Pose(angles=dict(POSES[name])), overrides)


def walk_pose(phase: float, amp: float = 28.0, **overrides) -> Pose:
    """Chu kỳ đi bộ thủ tục (facing=1). phase tuần hoàn trong [0,1)."""
    s = math.sin(2 * math.pi * phase)
    c = math.cos(2 * math.pi * phase)
    s2 = math.sin(2 * math.pi * (phase + 0.5))
    c2 = math.cos(2 * math.pi * (phase + 0.5))
    ang = {
        "torso": 4,
        "r_thigh": amp * s, "l_thigh": amp * s2,
        "r_shin": -50 * max(0.0, c), "l_shin": -50 * max(0.0, c2),
        "r_foot": -10 * max(0.0, c), "l_foot": -10 * max(0.0, c2),
        "r_arm": -0.8 * amp * s, "l_arm": -0.8 * amp * s2,
        "r_forearm": 20, "l_forearm": 20,
    }
    return _apply(Pose(angles=ang), overrides)


def run_pose(phase: float, **overrides) -> Pose:
    """Chu kỳ chạy thủ tục: biên độ lớn, gối gập sâu, thân nghiêng về trước."""
    p = walk_pose(phase, amp=50.0)
    c = math.cos(2 * math.pi * phase)
    c2 = math.cos(2 * math.pi * (phase + 0.5))
    p.angles.update({
        "torso": 14, "head": -6,
        "r_shin": -110 * max(0.0, c), "l_shin": -110 * max(0.0, c2),
        "r_forearm": 85, "l_forearm": 85,
    })
    return _apply(p, overrides)


# --------------------------------------------------------------------------
# Render SVG
# --------------------------------------------------------------------------


@dataclass
class Style:
    color: str = "#111111"
    head_fill: str = "#ffffff"   # "" hoặc "none" = đầu rỗng
    width: float = 5.0
    hand_r: float = 0.0          # >0: vẽ bàn tay tròn
    face: bool = True


def _f(v: float) -> str:
    return f"{v:.2f}"


def _face_svg(rig: Rig, pose: Pose, res: Solved, style: Style, sw: float) -> str:
    r = rig.head_r * pose.scale
    cx, cy = res.anchors["head_center"]
    head_world = res.segs["head"].world
    tilt = pose.facing * (180.0 - head_world)
    front = pose.view == "front"
    ex = [(-0.36 * r, -0.12 * r), (0.36 * r, -0.12 * r)] if front else [(0.45 * r, -0.15 * r)]
    mx0, mx1 = (-0.3 * r, 0.3 * r) if front else (0.12 * r, 0.62 * r)
    my = 0.38 * r
    fw = max(1.2, sw * 0.5)
    out = [f'<g transform="translate({_f(cx)} {_f(cy)}) rotate({_f(tilt)}) scale({pose.facing} 1)" '
           f'fill="none" stroke="{style.color}" stroke-width="{_f(fw)}" stroke-linecap="round">']
    er = max(1.6, 0.11 * r)
    for (x, y) in ex:
        if pose.eyes == "dot":
            out.append(f'<circle cx="{_f(x)}" cy="{_f(y)}" r="{_f(er)}" fill="{style.color}" stroke="none"/>')
        elif pose.eyes == "wide":
            out.append(f'<circle cx="{_f(x)}" cy="{_f(y)}" r="{_f(er * 1.7)}"/>')
        elif pose.eyes == "closed":
            out.append(f'<path d="M {_f(x - 0.14 * r)} {_f(y)} L {_f(x + 0.14 * r)} {_f(y)}"/>')
        elif pose.eyes == "happy":
            out.append(f'<path d="M {_f(x - 0.15 * r)} {_f(y + 0.05 * r)} Q {_f(x)} {_f(y - 0.22 * r)} '
                       f'{_f(x + 0.15 * r)} {_f(y + 0.05 * r)}"/>')
    xm = (mx0 + mx1) / 2
    if pose.mouth == "smile":
        out.append(f'<path d="M {_f(mx0)} {_f(my)} Q {_f(xm)} {_f(my + 0.3 * r)} {_f(mx1)} {_f(my)}"/>')
    elif pose.mouth == "sad":
        out.append(f'<path d="M {_f(mx0)} {_f(my + 0.12 * r)} Q {_f(xm)} {_f(my - 0.18 * r)} '
                   f'{_f(mx1)} {_f(my + 0.12 * r)}"/>')
    elif pose.mouth == "flat":
        out.append(f'<path d="M {_f(mx0)} {_f(my)} L {_f(mx1)} {_f(my)}"/>')
    elif pose.mouth == "open":
        out.append(f'<ellipse cx="{_f(xm)}" cy="{_f(my + 0.05 * r)}" rx="{_f(0.17 * r)}" ry="{_f(0.2 * r)}"/>')
    out.append("</g>")
    return "".join(out)


def figure_svg(rig: Rig, pose: Pose, style: Style | None = None) -> str:
    """Trả về một thẻ <g> SVG vẽ nhân vật. Ghép nhiều nhân vật/props vào cùng một svg_document."""
    style = style or Style()
    res = rig.solve(pose)
    sw = style.width * rig.line_scale * pose.scale
    parts = [f'<g stroke="{style.color}" stroke-width="{_f(sw)}" stroke-linecap="round" '
             f'stroke-linejoin="round" fill="none">']
    for chain in rig.spec["chains"]:
        names = chain["bones"]
        pts = [res.segs[names[0]].start] + [res.segs[n].end for n in names]
        pts_s = " ".join(f"{_f(x)},{_f(y)}" for x, y in pts)
        parts.append(f'<polyline points="{pts_s}"/>')
    if style.hand_r > 0:
        for k in ("l_hand", "r_hand"):
            x, y = res.anchors[k]
            parts.append(f'<circle cx="{_f(x)}" cy="{_f(y)}" r="{_f(style.hand_r * pose.scale)}" '
                         f'fill="{style.color}" stroke="none"/>')
    hx, hy = res.anchors["head_center"]
    fill = style.head_fill or "none"
    parts.append(f'<circle cx="{_f(hx)}" cy="{_f(hy)}" r="{_f(rig.head_r * pose.scale)}" fill="{fill}"/>')
    parts.append("</g>")
    if style.face:
        parts.append(_face_svg(rig, pose, res, style, sw))
    return "".join(parts)


def svg_document(inner: str, width: int, height: int, bg: str | None = "#ffffff") -> str:
    rect = f'<rect width="100%" height="100%" fill="{bg}"/>' if bg else ""
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" '
            f'viewBox="0 0 {width} {height}">{rect}{inner}</svg>')
