"""demo_rig.py — Vẽ contact sheet kiểm tra rig: pose mẫu, chu kỳ đi/chạy, biến thể thân hình, IK."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from stickrig import (POSES, Rig, Style, figure_svg, make_pose, mirror_pose,
                      run_pose, svg_document, walk_pose)

ROOT = Path(__file__).resolve().parent.parent
RIG_PATH = ROOT / "assets/rigs/default.rig.json"
CELL_W, CELL_H, FLOOR = 150, 230, 205


def label(x, y, text):
    return (f'<text x="{x}" y="{y}" font-family="sans-serif" font-size="11" '
            f'text-anchor="middle" fill="#666">{text}</text>')


def row_of(rig, poses, y0, labels=None, style=None, cell_w=CELL_W):
    out = []
    for i, p in enumerate(poses):
        p = p.copy()
        p.x = i * cell_w + cell_w / 2
        p = rig.ground(p, y0 + FLOOR)
        out.append(figure_svg(rig, p, style))
        out.append(f'<line x1="{i*cell_w+10}" y1="{y0+FLOOR}" x2="{(i+1)*cell_w-10}" y2="{y0+FLOOR}" '
                   f'stroke="#ddd" stroke-width="1"/>')
        if labels:
            out.append(label(i * cell_w + cell_w / 2, y0 + FLOOR + 16, labels[i]))
    return "".join(out)


def main(out_path="rig_preview.svg"):
    rig = Rig.load(RIG_PATH)
    style = Style()
    inner, y = [], 0

    # Hàng 1: pose mẫu
    names = list(POSES.keys())
    per_row = 8
    for start in range(0, len(names), per_row):
        chunk = names[start:start + per_row]
        inner.append(row_of(rig, [make_pose(n, eyes="dot") for n in chunk], y, chunk, style))
        y += CELL_H

    # Hàng: chu kỳ đi (8 frame) và chạy (8 frame)
    walk = [walk_pose(i / 8, view="side") for i in range(8)]
    inner.append(row_of(rig, walk, y, [f"walk {i}/8" for i in range(8)], style)); y += CELL_H
    run = [run_pose(i / 8, view="side") for i in range(8)]
    inner.append(row_of(rig, run, y, [f"run {i}/8" for i in range(8)], style)); y += CELL_H

    # Hàng: biến thể thân hình + biểu cảm + facing + gương
    row = []
    labels = []
    for v in rig.variants:
        r = Rig.load(RIG_PATH, v)
        row.append((r, make_pose("wave_a"))); labels.append(v)
    cells = []
    for i, (r, p) in enumerate(row):
        p = p.copy(); p.x = i * CELL_W + CELL_W / 2
        p = r.ground(p, y + FLOOR)
        cells.append(figure_svg(r, p, style) + label(i * CELL_W + CELL_W / 2, y + FLOOR + 16, labels[i]))
    # biểu cảm
    extra = [
        ("happy/open", make_pose("cheer", eyes="happy", mouth="open")),
        ("sad", make_pose("shrug", eyes="dot", mouth="sad")),
        ("facing -1", make_pose("point_fwd", facing=-1, view="side")),
        ("mirror", mirror_pose(make_pose("wave_a"))),
    ]
    for j, (lab, p) in enumerate(extra):
        i = len(row) + j
        p = p.copy(); p.x = i * CELL_W + CELL_W / 2
        p = rig.ground(p, y + FLOOR)
        cells.append(figure_svg(rig, p, style) + label(i * CELL_W + CELL_W / 2, y + FLOOR + 16, lab))
    inner.append("".join(cells)); y += CELL_H

    # Hàng IK: tay chạm các điểm đích, chân đặt lên bậc cao
    ik_cells = []
    targets = [(0, (40, -30)), (1, (30, -50)), (2, (-35, -45)), (3, (55, 25))]
    for i, (_, off) in enumerate(targets):
        p = make_pose("neutral")
        p.x = i * CELL_W + CELL_W / 2
        p = rig.ground(p, y + FLOOR)
        root = rig.solve(p).anchors["neck"]
        tgt = (root[0] + off[0], root[1] + off[1])
        p = rig.ik(p, "r_arm", tgt)
        ik_cells.append(figure_svg(rig, p, style))
        ik_cells.append(f'<circle cx="{tgt[0]:.1f}" cy="{tgt[1]:.1f}" r="4" fill="#e63946"/>')
        ik_cells.append(label(i * CELL_W + CELL_W / 2, y + FLOOR + 16, f"IK tay → đích"))
    # IK chân: đặt bàn chân phải lên bục
    for k, ang in enumerate((0, 1)):
        i = len(targets) + k
        p = make_pose("neutral"); p.x = i * CELL_W + CELL_W / 2
        p = rig.ground(p, y + FLOOR)
        hip = rig.solve(p).anchors["root"]
        tgt = (hip[0] + (35 if k == 0 else 20), y + FLOOR - (25 if k == 0 else 55))
        p = rig.ik(p, "r_leg", tgt)
        ik_cells.append(figure_svg(rig, p, style))
        ik_cells.append(f'<circle cx="{tgt[0]:.1f}" cy="{tgt[1]:.1f}" r="4" fill="#e63946"/>')
        ik_cells.append(label(i * CELL_W + CELL_W / 2, y + FLOOR + 16, "IK chân → đích"))
    inner.append("".join(ik_cells)); y += CELL_H

    w = per_row * CELL_W
    svg = svg_document("".join(inner), w, y)
    Path(out_path).write_text(svg, encoding="utf-8")
    print(f"Đã ghi {out_path} ({w}x{y})")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "rig_preview.svg")
